# MyFbFramework

## My FreeBasic Framework



#### Introduction

MyFbFramework is a forms building, drawing and etc. library for the FreeBASIC programming language. This library helps in the development of software products using easy-to-use classes and syntax, which are similar in nature to the programming language vb.net.

#### Some applications that use MyFbFramework
* [VisualFBEditor - IDE for FreeBasic](https://github.com/XusinboyBekchanov/VisualFBEditor)
